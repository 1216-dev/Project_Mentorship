export const APP_ID = '2164028c4655171c';
export const REGION = 'us';
export const AUTH_KEY = 'f3d63fefe93e94f58a70d3b0978bf307cc144c48';
