export const data = [
    {
        id: 0,
        coords: {
            latitude: 30.7993,
            longitude: 76.9149,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        },
    },
    {
        id: 1,
        coords: {
            latitude: 30.7786,
            longitude: 76.9060,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        },
    },
    {
        id: 3,
        coords: {
            latitude: 30.8333,
            longitude: 76.9357,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        },
    },
    {
        id: 4,
        coords: {
            latitude: 30.8406,
            longitude: 76.9584,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        },
    },
    {
        id: 5,
        coords: {
            latitude: 30.6936,
            longitude: 76.8450,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        },
    },
    {
        id: 6,
        coords: {
            latitude: 30.7333,
            longitude: 76.7833,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        },
    },
    {
        id: 7,
        coords: {
            latitude: 30.7333,
            longitude: 77.7833,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        },
    },
    {
        id: 8,

        coords: {
            latitude: 30.7333,
            longitude: 78.7833,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        },
    },
    
]