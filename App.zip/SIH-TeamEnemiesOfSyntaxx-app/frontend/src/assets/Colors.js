export const LinkedInBlue = "#0073b1";

export const LinkedInLightBlue = "#70b5f9";

export const LinkedInBgColor = "#f3f2ef";

export const lightPrimary = "#f5f5f5";

export const darkPrimary = "#363636";

export const darkSecondary = "#5c5c5c";

export const FacebookBlue = "#2e81f4";
