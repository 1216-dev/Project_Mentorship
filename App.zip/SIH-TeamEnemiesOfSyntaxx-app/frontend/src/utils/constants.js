import abi from "./docs.json";

export const contractAbi = abi.abi;
export const contractAddress = "0xdF202123104e6312497F6B676b5b76A0e457F23C";
