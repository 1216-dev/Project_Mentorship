# SIH-TeamEnemiesOfSyntaxx
This is our project made for Smart India Hackathon 2022 . We bagged the First place(Rewarded with cash prize of Rs.1,00,000 + Goodies) .

# We have Branches :
App Code : https://github.com/dishantzaveri/SIH-TeamEnemiesOfSyntaxx/tree/app
<br />Web Code : https://github.com/dishantzaveri/SIH-TeamEnemiesOfSyntaxx/tree/frontend
<br />Backend Code : https://github.com/dishantzaveri/SIH-TeamEnemiesOfSyntaxx/tree/backend
<br />ML Code : https://github.com/dishantzaveri/SIH-TeamEnemiesOfSyntaxx/tree/mlmodule
# Mentor Dots

'MentorDots' is a software platform for effective mentorship of startups by providing a one-stop solution for connecting experienced mentors with passionate entrepreneurs.

# Introduction

Hola Everyone, This is team The Enemies of Syntaxx which consists of 6 people of each and every stack. We have Dishant and Manan here for React Native, Mihir and Greha for Frontend and Yash and Vismay for AI/ML and Backend .

# Contributors :
<br />Dishant Zaveri (ReactNative) : https://github.com/dishantzaveri
<br />Manan Shah (ReactNative + React) : https://github.com/Manan17
<br />Mihir Shinde (React Frontend) : https://github.com/MihirShinde-29
<br />Greha Shah (React Frontend) : https://github.com/grehashah6
<br />Yash Joshi (Backend) : https://github.com/joshiyash05
<br />Vismay Vora (Backend) : https://github.com/VismayVora

# Case Study: Mentor Dots

India has 105 unicorns with funding over $93 billion. Shark Tank India has done its bit to increase awareness about the startup landscape, however this has hardly scratched the surface. A lot of the nation's entrepreneurial potential still remains untapped due to the lack of a support system. Thus, nurturing entrepreneurs requires a platform that provides robust support throughout the entire process to convert brilliant ideas into solid business models.

# What is so good about us?

Here at Mentor Dots , you'll be able to find various feature you are searching for. A designated place for all the software features That are availble on the internet . We provide proper description of along with the Voicebot to how to use the feature. 
 
The biggest reason of Mentor Dots software was to Help New Growing startup with the basic need of communication problem that they are facings with big companies and we are probably able to solve the problems 

The feature available in Mentor Dots are .
<br /> ->User Verification with GST number,CIN number,PAN number and Patent identification.
<br /> ->Pitch deck generator
<br /> ->Mentor mentee Recommendation system 
<br /> ->Video call and Chat feature
<br /> ->Selective mentoring feature 
<br /> ->Interactive Graphs and map for startup
<br /> ->Voice Bot
<br /> ->Government Schemes and Bootcamps
<br /> ->Object and sign detection For differently abled person 
<br /> ->Post like comment feature
<br /> ->Multilingual Website with 5 different languages

Success usually comes to those who are too busy to be looking for it.” – Henry David Thoreau

Now we are taking this time to introduce you guys with the web thing of our company which is basically a website.


# Overcoming The Challenges — Solution Overview
Web Preview : 

<p float="left">
<img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/1.jpeg" width = "40%" />
<img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/2.jpeg" width = "40%" />
<img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/3.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/4.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/5.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/6.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/7.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/8.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/9.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/10.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/11.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/12.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/13.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/14.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/feed.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/object detection.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/pitch deck.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/pitch deck ppt.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/sign detection.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/post.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/startups.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/profile page.jpeg" width = "40%" />
  </p>
  
# App Preview
 <p float="left">
<img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/start.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/log.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/1.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/2.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/3.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/4.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/5.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/6.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/7.jpeg" width = "40%" />
  <img src = "https://github.com/joshiyash05/acm/blob/main/backend/chat/assests/app/8.jpeg" width = "40%" />


 
<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://www.gnu.org/software/bash/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/gnu_bash/gnu_bash-icon.svg" alt="bash" width="40" height="40"/> </a> <a href="https://www.w3schools.com/css/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/> </a> <a href="https://www.djangoproject.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/django/django-original.svg" alt="django" width="40" height="40"/> </a> <a href="https://www.figma.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/figma/figma-icon.svg" alt="figma" width="40" height="40"/> </a> <a href="https://git-scm.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> </a> <a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> <a href="https://materializecss.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/prplx/svg-logos/5585531d45d294869c4eaab4d7cf2e9c167710a9/svg/materialize.svg" alt="materialize" width="40" height="40"/> </a> <a href="https://nodejs.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original-wordmark.svg" alt="nodejs" width="40" height="40"/> </a> <a href="https://postman.com" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/getpostman/getpostman-icon.svg" alt="postman" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> <a href="https://reactjs.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original-wordmark.svg" alt="react" width="40" height="40"/> </a> <a href="https://reactnative.dev/" target="_blank" rel="noreferrer"> <img src="https://reactnative.dev/img/header_logo.svg" alt="reactnative" width="40" height="40"/> </a> <a href="https://www.sqlite.org/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/sqlite/sqlite-icon.svg" alt="sqlite" width="40" height="40"/> </a> <a href="https://tailwindcss.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/tailwindcss/tailwindcss-icon.svg" alt="tailwind" width="40" height="40"/> </a> </p>
