
  import React from 'react'
  import { useHistory } from 'react-router-dom'
  
  const Home = () => {
  
    return (
      <div className="default-background">
      
          hi
      </div>
    )
  }
  export default Home
  