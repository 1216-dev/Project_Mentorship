from django.apps import AppConfig


class NewsandpolicisConfig(AppConfig):
    name = 'newsandpolicis'
    default_auto_field = 'django.db.models.BigAutoField'
