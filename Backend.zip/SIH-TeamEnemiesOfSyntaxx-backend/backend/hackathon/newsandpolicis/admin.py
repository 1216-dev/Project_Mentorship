from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Funding)
admin.site.register(Recomendation)
admin.site.register(Scheme)
