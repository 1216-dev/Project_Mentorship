export const randomNo = (min, max) =>
  Math.floor(Math.random() * (max - min) + min)
