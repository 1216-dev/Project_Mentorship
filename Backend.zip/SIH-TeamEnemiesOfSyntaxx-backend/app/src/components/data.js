export const data = [
  {
    question: 'Who will win sih',
    answer: 'Definitely not you',
  },
  {
    question: 'hi',
    answer: 'Hello',
  },
  {
    question: 'hello',
    answer: 'Hi',
  },
 
  {
    question: 'Why not me',
    answer: 'See your project progress dude',
  },
  {
    question: 'how are you',
    answer: 'I am fine',
  },
  {
    question: 'Bye',
    answer: 'Lmao',
  },
  {
    question: 'what is your name',
    answer: 'I am bot',
  },
  {
    question: 'how to use hand gesture tool?',
    answer: 'Open the tool , Try to maintain a distance of 1 m from the camera and keep a mark hands are properly visible and make gesture you want',
  },
  {
    question: 'how to use text to speech tool?',
    answer: 'Open the tool , Type the text you want to get that converterd in audio and click the button.',
  },
  {
    question: 'how to use speech to text tool?',
    answer: 'Open the tool , speak the audio you wanted to get that converted in text and click the button.',
  },
  {
    question: 'how to use Font simply tool?',
    answer: 'Open the tool , Upload the text which you want to read and click the button.',
  },
  {
    question: 'what is the purpose of the website?',
    answer: 'The website is built for specially disabbled person to decrease the difficulty faced by them in there day to day life ',
  },
  {
    question: 'how is todays weather ?',
    answer: 'Quite pleasant more sunny , hope you have a good day',
  },
  {
    question: 'Thank you',
    answer: 'Welcome :) hope i was able to guide you',
  }, 
  {
    question: 'how to login in ?',
    answer: 'You have already login as you have access to website enter the url of the website in your browser',
  },
];