import React from 'react';
import { DailyCall } from '@daily-co/react-native-daily-js';

export default React.createContext<DailyCall | null>(null);
